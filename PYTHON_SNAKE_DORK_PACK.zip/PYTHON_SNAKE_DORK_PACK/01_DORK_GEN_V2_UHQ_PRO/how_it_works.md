# Dork Gen v2 (UHQ Pro) kaise kaam karta hai

Bot 10 template families leta hai aur unme aapke keyword + random variables bharta hai:

```
(KW).(PF)?(PT)=                        →  shop.index?id=
(SF)(KW).(PF)?(PT)=(NB) site:(DE)      →  inurl:shop.view?id=2 site:.ru
(SF)(PT)=(KW).(PF)? site:(DE)          →  intitle:id=shop.view? site:.de
```

**Variables (random rotate hote hain):**
- KW = aapka keyword
- PF = index / view / page / item / product / user / login / search / show / cat
- PT = id / user_id / cat / type / page / item / product
- SF = inurl: / intitle: / allinurl: / allintitle:
- DE = .com .net .org .ru .de .in .pk .us .uk .info
- NB = 0 / 1 / 2 / 10

**Fayda:** 10 templates × 10 PF × 7 PT × 4 SF × 10 DE = **~28,000 unique dork** ek keyword pe.
Bot "exact count" deta hai — jitna maango, sab unique.
