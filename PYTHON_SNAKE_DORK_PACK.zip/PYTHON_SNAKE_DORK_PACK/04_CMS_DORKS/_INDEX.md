# CMS dorks

- **wordpress**: 10 dorks → `wordpress.txt`
- **joomla**: 10 dorks → `joomla.txt`
- **opencart**: 10 dorks → `opencart.txt`
- **prestashop**: 10 dorks → `prestashop.txt`
- **magento**: 10 dorks → `magento.txt`
- **drupal**: 7 dorks → `drupal.txt`
- **laravel**: 4 dorks → `laravel.txt`
- **codeigniter**: 4 dorks → `codeigniter.txt`
