# 🐍 PYTHON SNAKE — DORK PACK

> Banaya: 04 Nov 2026 • Source: `bot_fixed.py`
> Ye pack bot ke andar ka **saara** dork / keyword / SQLi / param data hai — organised text files me.

## Folder map

| Folder | Kya hai | Kitna |
|---|---|---|
| `01_DORK_GEN_V2_UHQ_PRO/` | **Dork Gen v2 (UHQ Pro)** ke 10 templates + variable pools | 10 templates |
| `02_CLASSIC_DORK_TEMPLATES/` | purane classic dork templates (12 category) | 223 templates |
| `03_UNIVERSAL_DORKS/` | Universal Dork Engine ke 7 families + niche table | 7 families |
| `04_CMS_DORKS/` | WordPress / Joomla / Drupal … dorks | 8 CMS |
| `05_KEYWORD_PACK/` | payment seeds + keyword templates + niche words | 34 seeds |
| `06_SQLI_PACK/` | payloads + gold params + sensitive fields | 10 payload |
| `07_PARAMS_EXTS_TLDS/` | params / extensions / TLDs / pages / file names | 132+ |
| `08_ALL_IN_ONE/` | sab kuch ek file me + ready-to-use dork list | — |

## Placeholders (template me ye badalte hain)

| Placeholder | Matlab | Values kahan |
|---|---|---|
| `{kw}` / `{KW}` | keyword | aapka keyword |
| `{param}` / `{PT}` | URL parameter | `07_.../params.txt` |
| `{PF}` | page name | `01_.../variables.txt` |
| `{DE}` | domain TLD | `.com .net .ru …` |
| `{NB}` | number | 0 / 1 / 2 / 10 |
| `{SF}` | search filter | `inurl:` `intitle:` … |

## Kaise use kare

1. Template file se ek line uthao → placeholders bharo → Google me daalo.
2. Ya `08_ALL_IN_ONE/ready_dorks.txt` seedha uthao — already bhare hue dorks.
3. Dork Gen v2 ke templates **UHQ Pro** hain — `(SF)(KW).(PF)?(PT)=(NB) site:(DE)` type ke advanced.

## Note
Ye **template/reference pack** hai (bot ka data). Koi live exploit ya credential nahi hai.
