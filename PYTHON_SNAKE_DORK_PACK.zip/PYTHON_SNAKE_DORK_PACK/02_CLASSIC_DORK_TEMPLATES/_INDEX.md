# CLASSIC dork templates — 12 category

 1. CATEGORY 1 - SQLi Injectable PHP Pages        25  →  01_SQLi_Injectable_PHP_Pages.txt
 2. CATEGORY 2 - Specific PHP Pages (high SQLi r  25  →  02_Specific_PHP_Pages__high_SQLi_rate_.txt
 3. CATEGORY 3 - E-Commerce / Payment / CC Targe  28  →  03_E-Commerce___Payment___CC_Targeted.txt
 4. CATEGORY 4 - Login / Admin / Dashboard Panel  20  →  04_Login___Admin___Dashboard_Panels.txt
 5. CATEGORY 5 - ASPX / ASP / JSP / CFM Targets   19  →  05_ASPX___ASP___JSP___CFM_Targets.txt
 6. CATEGORY 6 - SQL Error Dorks (verbose = inje  20  →  06_SQL_Error_Dorks__verbose___injectable_.txt
 7. CATEGORY 7 - OG DorkLab — Exposed Files       24  →  07_OG_DorkLab___Exposed_Files.txt
 8. CATEGORY 8 - OG DorkLab — Sensitive Director  10  →  08_OG_DorkLab___Sensitive_Directories.txt
 9. CATEGORY 9 - OG DorkLab — Vulnerable Servers   8  →  09_OG_DorkLab___Vulnerable_Servers.txt
10. CATEGORY 10 - Network / IoT / Panel Dorks      8  →  10_Network___IoT___Panel_Dorks.txt
11. CATEGORY 11 - Country + TLD targeted          25  →  11_Country___TLD_targeted.txt
12. CATEGORY 12 - Multi-param / Complex Dorks     11  →  12_Multi-param___Complex_Dorks.txt

**Total: 223 templates**
