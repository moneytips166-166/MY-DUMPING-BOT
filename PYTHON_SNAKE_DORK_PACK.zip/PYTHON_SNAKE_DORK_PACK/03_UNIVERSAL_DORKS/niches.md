# Niche table

## Niche → detect words
- **gaming**: steam, valorant, pubg, fortnite, roblox, cdkey, gamepass, riot, epic
- **ott**: netflix, spotify, prime, disney, crunchyroll, iptv, hotstar, hulu
- **crypto**: btc, usdt, ethereum, crypto, binance, wallet, coinbase, binancepay
- **hosting**: cpanel, whm, vps, hosting, saas, domain, cloud, plesk, whmcs
- **ecom**: shopify, woocommerce, magento, checkout, cart, store, product, order
- **finance**: bank, loan, insurance, invoice, payment, billing, wallet, paypal
- **edu**: school, college, student, exam, result, university, admission
- **health**: hospital, clinic, doctor, patient, pharmacy, appointment
- **travel**: hotel, booking, flight, ticket, tour, reservation
- **gov**: gov, municipal, portal, citizen, tax, license

## Niche → extra terms
- **gaming**: steam wallet, game topup, gift card, cd key
- **ott**: premium account, subscription, free trial, iptv
- **crypto**: usdt, bitcoin, wallet, exchange
- **hosting**: cpanel, whmcs clientarea, vps panel
- **ecom**: checkout, cart, order, invoice
- **finance**: netbanking, invoice, statement, billing
- **edu**: student portal, exam result, admission form
- **health**: patient portal, appointment, prescription
- **travel**: booking, reservation, ticket
- **gov**: citizen portal, tax payment, license
- **general**: login, account, dashboard, panel
