# Universal Dork Engine — 7 families

Keyword dekh ke niche khud detect hota hai, phir ye families chalti hain:

| # | Family | Format |
|---|---|---|
| A | page + param + ext | `{term} inurl:{page}.{ext}?{param}=` |
| B | plain inurl param | `{term} inurl:?{param}=` / `allinurl:?{param}=` |
| C | niche + param + TLD | `"{term}" inurl:?{param}= site:{tld}` |
| D | mod + page | `{mod} {term}{page}` |
| E | api / ajax / json / rest | `{term} inurl:api?{param}=` |
| F | admin / panel / dashboard | `{term} inurl:admin inurl:?{param}=` |
| G | filler | jab count bacha ho |

**Variables:** pages 33 • params 41 • exts 8 • mods 11 • TLDs 20
